1.To run the program open the folder name Arcade
2.Run LoginGUI.jar 
3.Create an account, if you don't have one and are not admin.

Admin Login
***********
  Admin Login is Username:Admin Password:Admin (it is case senstive)
	Admin account
	login:Bains
	Password:0000
The admin can remove player and has accses to the settings

To check HighScores
*******************
in order to check the highscores, go to the main menu and click on highscores.

Sorting highscore by game
*************************
go to high scores and click sort by Bainsy or Snake.
after clicked the scores are ordered by highscore per game.

Snake game Controls
*******************
P = pause 
Arrows = move snake (up, down, left, right)

Bainsy Bird controls
********************
jump = up arrow

For More Information about the program you can check UserManualV1.pdf under folder: Arcade