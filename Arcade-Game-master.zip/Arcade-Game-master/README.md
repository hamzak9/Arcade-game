# Arcade-Game
Simple arcade game that includes popular games including Flappy Bird and Snake. 

1.To run the program open the folder name Arcade

2.Run LoginGUI.jar 

3.Create an account, if you don't have one and are not admin.
